package casamento;

public class KMP {

	public static int search(String pat, String txt) {
        int result = -1;
		int M = pat.length();
		int N = txt.length();

		int j = 0; // index for pat[]

		int[] lps = generateKMPTable(pat);

		int i = 0; // index for txt[]
		while (i < N) {
			if (pat.charAt(j) == txt.charAt(i)) {
				j++;
				i++;
			}

			if (j == M) {
                result = i - j;
                break;
			}

			// mismatch after j matches
			else if ((i < N) && (pat.charAt(j) != txt.charAt(i))) {
				// Do not match lps[0..lps[j-1]] characters,
				// they will match anyway
				if (j != 0) {
					j = lps[j - 1];
				} else {
					i = i + 1;
				}
			}
		}
        return result;
	}

	private static int[] generateKMPTable(String pat) {
		int len = 0;
		int i = 1;
		int length = pat.length();
		int[] output = new int[length];
		output[0] = 0;

		while (i < length) {
			if (pat.charAt(i) == pat.charAt(len)) {
				len++;
				output[i] = len;
				i++;
			} else {
				if (len != 0) {
					len = output[len - 1];
				} else {
					output[i] = 0;
					i++;
				}
			}
		}
		return output;
	}
}