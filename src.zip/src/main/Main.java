package main;
import interfaces.*;

public class Main {
    public static void main(String[] args) {
        Menus menus = new Menus();
        menus.login();
    }
}