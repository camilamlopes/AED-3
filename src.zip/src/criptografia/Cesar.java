package criptografia;

public class Cesar {
    public static int factor;

    public static String criptografar(String s) {
        StringBuilder result = new StringBuilder();
        for (char c : s.toCharArray()) {
            result.append(((int) c + factor < 256) ? (char) (c + factor) : (char) ((int) c + factor - 256));
        }
        return result.toString();
    }

    public static String descriptografar(String s) {
        StringBuilder result = new StringBuilder();
        for (char c : s.toCharArray()) {
            result.append((int) c - factor >= 0 ? (char) (c - factor) : (char) ((int) c - factor + 256));
        }
        return result.toString();
    }
}
